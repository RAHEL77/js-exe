var tgp = [];
var q = document.querySelectorAll(".div");
for (var i = 0; i < q.length; i++) {
    q[i] = tgp + i;
    console.log(q[i])

}